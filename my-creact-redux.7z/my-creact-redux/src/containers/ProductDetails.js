import React from "react";

const ProductDetail = () => {
  return (
    <div>
      <h2>ProductDetail</h2>
    </div>
  );
};

export default ProductDetail;
