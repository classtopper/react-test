import React from "react";
import { useSelector } from "react-redux";

const ProductComponent = () => {
  const products = useSelector((state) => state.allProducts.products);
  
  const offers = (products.offers);
    if(offers)
    {
        const renderList = offers.map((offer) => {
            const {id, acrissCode, prices, images} = offer;
            return (
              <div className="four column wide" key = {id}>
              <div className="ui link cards">
                <div className="card">
                  <div className="image">
                     
                      {/* <img src = {images.small} alt ={acrissCode}></img>
                    <img src={images.small} onError={(e)=>{e.target.onerror = null; e.target.src="%PUBLIC_URL%/logo192.png"}}/>  */}  
                
                  </div>
                  <div className="content">
                    <div className="header">{acrissCode}</div> 
                    <div className="meta price">$ {prices.totalPrice.amount.value}</div> 
                  </div>
                </div>
              </div>
            </div>
            );
        });
      
        return <> { renderList } </>;
    }
    else
    {
        return (<div>No record found!</div>);
    }
  
};


export default ProductComponent;
