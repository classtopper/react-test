import React, {useEffect} from "react";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import {selectedProduct,removeSelectedProduct} from "./redux/actions/productActions";
import { prettyDOM } from "@testing-library/dom";


const ProductDetail = () => {
  const product = useSelector((state) => state.product);
  const {id, image, descriptoin, price} = product;
  const {productId} = useParams();
   
  const dispatch = useDispatch();
  console.log(productId);

  const fetchProductDetail = async () =>{
    const response = await axios
    .get(`hptts://api.com/${productId}`)
    .catch((err) =>{
      console.log("Error", err);
    } );

    dispatch(selectedProduct(response.data));
  };

  useEffect(() =>{
    if (productId && productId != "") fetchProductDetail;
    return() => {
      dispatch(removeSelectedProduct());
    }
  }, [productId] )

  return (
    <div className="ui grid container">
       <div className = ""> </div>
    </div>
  );
};

export default ProductDetail;
