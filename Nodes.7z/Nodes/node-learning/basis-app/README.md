REPL: 
REPL (Read-Eval-Print-Loop) JS is a JavaScript editor that evaluates your code as you type and gives you the power of time travel all while making your experiments easily accessible by you or whoever you chose to share them with. 

command:
>node 
> console.log("Hello node programming!")

NPM: Node package manager allows to install different node packages in the application. 

- Init : to initialize the project.
- init -y : default prpject initialization

ex: npm init or nmp init -y
/** 
console.log('hello')
const a = 10
const b = 20

console.log("the value of a is %s and b is %s", a, b)
const os = require('os')
console.log(os.type())  */
const path = require('path')
const car = {
    brand:"BMW",
    model: "Z4"
}

console.log('hello')
console.log(Date.now());

//module.exports = car
exports.car = car

NPX: The npx stands for Node Package Execute and it comes with the npm, when you installed npm above 5.2.0 version then automatically npx will installed. It is an npm package runner that can execute any package that you want from the npm registry without even installing that package.

Package.json: to configure project or package

package version: to set the package version

Event Loop: Node. js uses callbacks, being an asynchronous platform, it does not wait around like database query, file I/O to complete.

when node executes functions, it put is in call stack and executes one by one. If any setTimeout is used for a function then that function is put under message queue and execute one by one.

Example:

const bar = () => { console.log("bar")}
const store = () => {console.log("store")}
const hero = () =>{
    console.log("Hero");
    bar()
    store()
}
hero()

-------------

const bar = () => { console.log("bar")}
const store = () => {console.log("store")}
const hero = () =>{
    console.log("Hero");
    setTimeout(bar, 1000); 
    store()
}
hero()

Callback: to solve the asynchronous problem, a callback is used.
Example:
const bar = (message, callback) => { 
    setTimeout(() => {
        console.log(message)
        callback()
    }, 1000);
}
const store = () => {console.log("store")}

bar("bar", store)

Promise: Is class to solve the asynchronous problem.
Example:
const promise = new Promise((resolve, reject) =>{
    setTimeout(() =>resolve("first msg!"), 1000);
});

promise.then(result =>{
    console.log(result)
    GetMsg()
} ,
    err => console.log(err))

function GetMsg()
{
    console.log("print second");
}

Async & Await: Extension of promise and callback


function createMsg(){
    const promise = new Promise((resolve, reject) =>{
        setTimeout(() =>resolve("first msg!"), 2000);
    });
    return promise;
}

async function GetMsg(callback)
{
    var msg = await createMsg()
    console.log(msg);
    console.log("print second");
    callback()
}

GetMsg(display)

function display(){
    console.log('Displayed something')
}

HTTP Server: used to create server to run on web browser.
Example: 
const http = require('http')
const hostname = '127.0.0.1'
const port = 3000

const server = http.createServer((req,res) =>{
    res.statusCode = 200;
    res.setHeader('Content-Type','text/plain');
    res.end("Welcome to HTTP Server.");
})

server.listen(port,hostname,()=> {
    console.log(`Server running at http://${hostname}:${port}/`);
})

Another example:

const http = require('http')
const hostname = '127.0.0.1'
const port = 3000

const server = http.createServer((req,res) =>{
    res.writeHead(200, {'Content-Type':'text/plain'});
    res.write("Welcome to HTTP Server.");
    res.end();
}).listen(port,hostname,()=> {
    console.log(`Server running at http://${hostname}:${port}/`);
})

Http Request: Get ():
const http = require('http')

http.get('http://api.open-notify.org/astros.json', resp =>{
let data = '';    
resp.on('data', chunk =>{
        data += chunk
});

resp.on('end', () => {
    let jsondata = JSON.parse(data)
    console.log(jsondata)
    });
})

Http Post Request:
const http = require('https');

const data = JSON.stringify({
    name: "John Doe",
    Job: "Content Writer"
});

const options = {
    hostname:'regres.in',
    path:'/api/users',
    method:'POST',
    header:{
        'Content-Type':'application/json'
    }
};

//request
const req = http.request(options, (res)=>{
    let body = '';
    console.log("Status Code:", res.statusCode)

    res.on('data', (chunk) => {
        body += chunk;
    })

    res.on('end', () => {
        console.log("Body:", JSON.parse(body));
    })
})
req.write(data)
req.end();

axios library:
Example:
const axios = require('axios');

const data = JSON.stringify({
    name: "John Doe",
    Job: "Content Writer"
});


axios.post('https://reqres.in/api/users', data).then( res =>{
    console.log(`Status code: ${res.status}`);
    console.log(`Body: ${JSON.stringify(res.data)}`);
}).catch(err =>{
    console.log(err)
})

Files:
Read:
//async
const fs = require('fs');
fs.readFile("text.txt", 'utf8', (err, data) =>{
    if(err) throw err;
    console.log(data)
})

//sync
const data = fs.readFileSync("text.txt", {encoding:'utf-8', flag : 'r'})
console.log(data);

fs.stat('text.txt', (err, stats) =>{
    if(err){
        console.log(err);
        return
    }
    console.log(stats.isFile())
    console.log(stats.isDirectory())
    console.log(stats.isSymbolicLink())
    console.log(stats.size)
})

Write:

const fs = require('fs');

const content = "\nHello Node";

//fs.writeFileSync("text.txt", JSON.stringify(content));

fs.writeFile('text.txt', content, {flag: 'a+'}, err =>{
    if(err){
        console.log(err);
        return
    }
    console.log("Successfully done!")
})

delete file:

fs.unlink("text.txt", err =>{
    if(err){
        console.log(err);
    }
    console.log("file deleted")
})

Routing:

const http = require('http');

const routes = {
    '/':function index(request, response)
    {
        response.writeHead(200);
        response.end("Node Routing");
    },
    '/aboutus':function aboutus(request, response)
    {
        response.writeHead(200);
        response.end("About Us");
    }
}

http.createServer((req, res) =>{
    if(req.url in routes ){
        return routes[req.url](req, res);
    }
    
}).listen(process.env.PORT || 3000, ()=>{
    console.log('Server is running.')
})

Path:

const path = require('path');

//const file = path.parse('basic/index.js');
const file = path.resolve('index.js');
//const pt = path.join('C:/Users/a.kumar/Desktop/Arvind-PC/', 'Arvind/Nodes/node-learning/Basics')
//const file = path.isAbsolute(pt);

console.log(file);

Events Module:

const events = require('events');

let ev = new events.EventEmitter();
ev.on('my_event', function(data){
    console.log("Event:", data);
})

//ev.once('eventOnce', ()=> console.log('EventOnes once fired'));
ev.once('eventOnce', (code, msg)=> console.log(`${code} ${msg}`));

ev.emit('my_event', "event method is called");
ev.emit('eventOnce', 200, 'ok');

//unregister the event
const c1 = (code, msg)=> console.log(`${code} ${msg}`);
ev.off('eventOnce', c1)

Stream: Memory efficieny and time efficiency
ex:
const http = require('http');
const fs = require('fs');
const server = http.createServer(
    function(req, res){
        // fs.readFile('test.json', (err,data) =>{
        //     res.end(data);
        // })

        const stream = fs.createReadStream('test.json');
        stream.pipe(res);
    }
)

server.listen(3000 , () =>{
    console.log('Server is running!')
})

Buffer:
ex:

//const buffer = Buffer('Hello');
 const buffer = Buffer.alloc(4);

buffer.write('Nice')

console.log(buffer.toString());
console.log(buffer[0]);
console.log(buffer[1]);
console.log(buffer[2]);
console.log(buffer[3]);
console.log(buffer[4]);

Exception Handling:

//throw new Error("Erro occured")

try{
    console.log("Start try block")
    throw new Error('New error')
} catch(err){
    console.log("Error occuerd", err.message)
}

async function DoTask()
{
    try{
        await NextTask();
    }catch(err){
        console.log('Error', err.message)
    }
}

Express: framework to build web app. fast & easy
Simple Web server, Middleware, function programming, Restful api, template and database.

ex:
const express = require('express');
const app = express();

app.get("/",(req, res) =>{
    res.send("Express Server");
});

app.get("/hello",(req, res) =>{
    res.send("Welcome to Express Server");
});

app.listen(3000, () =>{ console.log('Express server is running')});

Middleware: function to have req and res object and call next middleware function. Logging and authentication.
use() is to call middleware function.

Ex:
const express = require('express');
const app = express();

const myLogger = function(reg, res, next){
    console.log('Logged');
    next();
}

const reuestTime = function(req, res, next){
    req.reqTime = Date.now();
    next();
}

app.use(myLogger)
app.use(reuestTime)

app.get("/",(req, res) =>{
    res.send(`Current time: ${req.reqTime}`);
});

app.listen(3000, () =>{ console.log('Express server is running')});

Static File:
const express = require('express');
const app = express();
const path = require('path');


const publicpath = path.resolve(__dirname, 'public');

app.use(publicpath, express.static('static'));
//app.use(express.static('public'));

<img src="pubic/image.jpg"> </img>

app.get("/",(req, res) =>{
    res.send('Static files');
});

app.listen(3000, () =>{ console.log('Express server is running')});

Routing with Express:


const express = require('express');
const app = express();
const path = require('path');
 
const publicpath = path.resolve(__dirname, 'public');

 
app.get("/",(req, res) =>{
    res.send('Welcome to my home page');
});
app.get("/about",(req, res) =>{
    res.send('Welcome to about page');
});
app.get("/weather",(req, res) =>{
    res.sendFile(path.join(publicpath, 'index.html'));
    
});

app.listen(3000, () =>{ console.log('Express server is running')});

Views:

const express = require('express');
const app = express();
const path = require('path');

app.set('view engine', 'pug');
//app.set('views', './views');

app.get('/', (req, res)=>{
    res.render('index', {title:'Express Engine', h1:'Express App', p:'Express Template Engine' })
});

app.listen(3000, () =>{ console.log('Express server is running')});
---------
pug-- index.pug
html
    title=title
    body
        h1=h1 
        p=p

session:
const express = require('express');
const app = express();
const session = require('express-session');

app.use(session({
    secret:"secret key",
    resave: true,
    saveUninitiazed:true
}));

app.get('/', (req, res)=>{
    req.session.name="Nodejs"
    return res.send('Session is set')
});
app.get('/session', (req, res)=>{
    var name = req.session.name;
    return res.send(name);
});

app.get('/destroy', (req, res)=>{
    req.session.destroy( (err) =>{
        console.log('Session destroyed.')
    });
    return res.end('Destroyed!');
});

app.listen(3000, () =>{ console.log('Express server is running')});

Cookies:
const express = require('express');
const app = express();
const cookies = require('cookie-parser');

app.use(cookies());

let users = {name:"John", Age:30};

app.get('/', (req, res)=>{
     res.send('Cookie')
});

app.get('/setuser', (req, res)=>{
     res.cookie('userdata', users);
     res.send('user data added to cookies');
});

app.get('/getuser', (req, res)=>{
    res.send(req.cookies);
});

app.get('/logout', (req, res)=>{
    res.clearCookie('userdata');
    res.send('User logout successfully!')
});

app.listen(3000, () =>{ console.log('Express server is running')});




