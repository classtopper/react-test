

async function DoTask()
{
    try{
        await NextTask();
    }catch(err){
        console.log('Error', err.message)
    }
}