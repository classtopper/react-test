
const car = require("./index")
console.log(car);