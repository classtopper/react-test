
const express = require('express');
const app = express();
const cookies = require('cookie-parser');

app.use(cookies());

let users = {name:"John", Age:30};

app.get('/', (req, res)=>{
     res.send('Cookie')
});

app.get('/setuser', (req, res)=>{
     res.cookie('userdata', users);
     res.send('user data added to cookies');
});

app.get('/getuser', (req, res)=>{
    res.send(req.cookies);
});

app.get('/logout', (req, res)=>{
    res.clearCookie('userdata');
    res.send('User logout successfully!')
});

app.listen(3000, () =>{ console.log('Express server is running')});

