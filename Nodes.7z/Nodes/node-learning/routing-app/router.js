
const express = require('express');
const route = express();
var accounts = require('./database');

//Get request

route.get('/accounts',(req, res)=>{
    res.json({userData:accounts});
})
route.post('/accounts',(req, res)=>{
    const newuser = req.body
    accounts.push(newuser);
    res.json(accounts);
})

route.get('/accounts/:id',(req, res)=>{
    const accountid =Number(req.params.id);
    const findId = accounts.find((account)=>account.id === accountid);
    if(!findId){
        res.status(500).send('Account not found');
    }else{
        res.json({userData:[findId]});
    }
})

route.put('/accounts/:id',(req, res)=>{
    const accountid =Number(req.params.id);
    const body = req.body;
    const findId = accounts.find((account)=>account.id === accountid);
    const index = accounts.indexOf(findId)
    if(!findId){
        res.status(500).send('Account not found');
    }else{
        const updatedUser = {...findId,...body };
        //console.log({findId, body});
        accounts[index] = updatedUser;
        res.send(updatedUser);
    }
})
route.delete('/accounts/:id',(req, res)=>{
    const accountid =Number(req.params.id);
    const newAccounts = accounts.filter( (account) => account.id != accountid);
    if(!newAccounts){
        res.statusCode(500).send('Account not found!');
    }else{
        accounts = newAccounts;
        res.send(accounts);
    }
     
})
module.exports = route;