let accounts = [{
    "id":1,
    "username": "Manav",
    "email" : "manav@gmail.com",
    "gender":"Male",
    "status":"Inactive"
},
{
    "id":2,
    "username": "Riti",
    "email" : "riti@gmail.com",
    "gender":"Female",
    "status":"Active"
}];

module.exports = accounts;