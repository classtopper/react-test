module.exports = {
    PORT: 5000,
    MONGO_URI: 'mongodb://localhost/ecom-api-dev',
    JWT_SECRET: 'secret',
    JWT_SECRET_CART: 'cartsecret'
};