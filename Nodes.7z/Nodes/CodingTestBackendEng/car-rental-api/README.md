## Introduction

This project is a implementation of a Car Rental API in [Node.js](https://nodejs.org/en/).
It uses [Express](https://expressjs.com/) as web framework and [MongoDB](https://www.mongodb.com/) as database.
 
## Installation

In order to run the application on your local machine some requirements need to be installed.

#### Node.js
 

#### MongoDB
 

#### Dependencies

Change the directory to the project folder and install the dependencies.

```
npm install
```

## Tests

Run the tests to make sure everything is installed correctly and working.

```
npm test
```

## Usage

Finally, start the Node web server.

```
npm start
