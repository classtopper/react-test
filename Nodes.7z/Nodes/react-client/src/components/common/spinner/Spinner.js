import React from 'react';
import './Spinner.css';

export default props => <div className={props.classNames}></div>;