import React from "react";

const NotFound = () => <h2 className='not-found'>404 Page Not Found :(</h2>;

export default NotFound;