const express = require("express");
const app = express();

const pets = ["Cow", "Horse", "Elephant", "Dog", "Cat"];

app.get('/', (req, res) => {
    res.send(pets);
});

app.listen(3000, () =>{
    console.log('Server is listening on port 3000');
});
