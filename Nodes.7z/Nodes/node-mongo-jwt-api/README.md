# node-mongo-jwt-refresh-tokens-api

Node.js + MongoDB API - JWT Authentication with Refresh Tokens

For documentation and tutorial see https://jasonwatmore.com/post/2020/06/17/nodejs-mongodb-api-jwt-authentication-with-refresh-tokens