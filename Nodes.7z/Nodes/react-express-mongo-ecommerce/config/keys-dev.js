module.exports = {
    PORT: 5000,
    MONGO_URI: 'mongodb://localhost/react-ecommerce-test',
    JWT_SECRET: 'secret',
    JWT_SECRET_CART: 'cartsecret'
};